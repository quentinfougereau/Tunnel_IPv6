#ifndef H_IFTUN
#define H_IFTUN

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h> 
#include <sys/stat.h>
#include <sys/ioctl.h>

#include <unistd.h>
#include <fcntl.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#define SIZE_BUFFER 1024

void iftun(int src, int dest);

#endif
