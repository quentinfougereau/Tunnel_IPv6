#ifndef H_TRAITEMENT
#define H_TRAITEMENT

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void test(int read_count, char buffer[]);
char * tailleauto(unsigned char buffer[], int length_pos, int packet_size);

#endif
